/*******************************************
 Valid for AVR_ATmega168,AVR_ATmega48,AVR_ATmega88,AVR_ATmega328P,AVR_ATmega1280
*/
#include "Arduino.h"
#include "rtOS.h"

rtOS::rtOS(unsigned int ms)
{
  TIMSK2 &= ~(1<<TOIE2);// Timer stop
  TCCR2A &= ~((1<<WGM21) | (1<<WGM20));
  TCCR2B &= ~(1<<WGM22);//normal mod UP
  TIMSK2 &= ~(1<<OCIE2A);
   // prescaler set to 32*256; input tic 500us
    TCCR2B &= ~((1<<CS22)|(1<<CS21)|(1<<CS20));
    tcnt2 = 256 - 1;
  if (ms == 0)   msecs = 1;
  else    msecs = ms;
  for (byte i=0;i<8;i++) { // rtOS task period init
  if  (dT[i]>0)  td[i]=dT[i];
  if  (dT[i]==0)  td[i]=tT[i];}
}
void rtOS::start()
{
  count = 0;
  overflowing = 0;
  TCNT2 = tcnt2;
  TIMSK2 |= (1<<TOIE2);
}

void rtOS::stop()
{
  TIMSK2 &= ~(1<<TOIE2);
}

void  rtOS::_overflow()
{
  count += 1;
  if (count >= msecs && !overflowing) {
    overflowing = true;
    count = 0;
    }
  if(overflowing) {
    overflowing= false;
    for (byte i=0;i<8;i++) {  // init task period regs
    --td[i];
    if  (td[i]==0) {
    td[i]=tT[i];
    flag|=(1 << i);
   }
  }
 }
}
void rtOS::loop()
{
  for(tsk=0;tsk<8;tsk++) {
    if (flag & (1 << tsk)) {
    flag&=~(1 << tsk);
    switch (tsk) {
    case 0: task0();
    break;
    case 1: task1();
    break;
    case 2: task2();
    break;
    case 3: task3();
    break;
    case 4: task4();
    break;
    case 5: task5();
    break;
    case 6: task6();
    break;
    case 7: task7();
    break;}}}
}
