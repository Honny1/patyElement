#ifndef rtOS_h
#define rtOS_h

#include "Arduino.h"
extern void task0(),task1(),task2(),task3(),task4(),task5(),task6(),task7();
extern const byte dT[8],tT[8];

class rtOS
{
  public:
    rtOS(unsigned int ms);
    void start();
    void stop();
    void loop();
    unsigned int tcnt2;
    void _overflow();
private:
    unsigned int msecs;
    unsigned int count;
    bool overflowing;
    volatile byte flag,tsk,td[8];
};
#endif
